WHY BUILD ANOTHER ADDRESS BOOK?

Why build another address book?
I created this address book because I was frustrated with
current address book solutions which try to integrate
everything.  The current software-industry ( or projects )
trend towards pushing users personal information into the
cloud; is alarming, not so-much about where the data is
stored but how badly data is leaked, hacked, and compelled
( by law enforcement ) for data access. Additionally,
cloud services have let me down by corrupting data, failing
to secure data, and worst of all; deleting data when
I needed it most.

Perhaps, more simply-put, I wanted an address book that
no-one may control but me, is simple, and cloudless.

After all clouds mean rain and I've had enough of it.
So, get this address book and take control of your
data.

RELEASE NOTES

Added sorting to grids for main dashboard and relationships. Table headers sort by clicked column header.
Added postal code and status to address tab on dashboard to match address entry window.
Added settings for default window sizes so users can adjust, if needed, for their operating system. Change defaults by editing settings.py file.
Allow users to change the default search LIMIT on rows returned for search. Change defaults by editing settings.py file.

INSTALL DIRECTIONS
Unfortunately I have not figured out how to get setup tools to cooperate with entry_points

Therefore:
FIRST: Backup your database if you already installed a prior version.

pip3.4 install addressbook
Then launch addressbook/main.py from the site-packages folder
Example: (Current directory) site-packages/addressbook python3.4 main.py

If you have an existing database will not be overwritten, but again, just back it up first in case I made a mistake.

